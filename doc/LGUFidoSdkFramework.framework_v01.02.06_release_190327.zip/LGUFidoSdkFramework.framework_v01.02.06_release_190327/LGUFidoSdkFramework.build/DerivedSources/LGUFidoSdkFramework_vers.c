 extern const unsigned char LGUFidoSdkFrameworkVersionString[];
 extern const double LGUFidoSdkFrameworkVersionNumber;

 const unsigned char LGUFidoSdkFrameworkVersionString[] __attribute__ ((used)) = "@(#)PROGRAM:LGUFidoSdkFramework  PROJECT:DasFidoFramework-1" "\n";
 const double LGUFidoSdkFrameworkVersionNumber __attribute__ ((used)) = (double)1.;
