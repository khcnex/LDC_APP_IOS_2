//
//  DeviceInfo.h
//  newwebtoon
//
//  Created by Claude Chey on 2015. 7. 30..
//  Copyright (c) 2015년 Claude Chey. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DeviceInfo : NSObject

//+ (NSString*)getAppVersion;
+ (NSString*)getUUID;
+ (NSString*)getSurrogateKey;
//+ (NSString*)getDeviceModel;

@end
