//
//  ViewController.h
//  SelvyOCRforMobileScanDemo
//
//  Created by selvas on 2018. 9. 8..
//  Copyright © 2018년 SelvasAI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

