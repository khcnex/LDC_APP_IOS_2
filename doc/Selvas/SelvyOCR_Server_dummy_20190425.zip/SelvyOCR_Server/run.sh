LD_LIBRARY_PATH="3rdparty:$LD_LIBRARY_PATH" ./selvy_recognition_server
