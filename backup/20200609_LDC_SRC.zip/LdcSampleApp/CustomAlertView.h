#import <UIKit/UIKit.h>

@interface CustomAlertView : UIView

//@property (weak, nonatomic) IBOutlet UITextView *txt_permission;
@property (weak, nonatomic) IBOutlet UIButton *btn_denied;
@property (weak, nonatomic) IBOutlet UIButton *btn_allow;

@end
