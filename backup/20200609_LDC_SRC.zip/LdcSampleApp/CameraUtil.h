#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface CameraUtil : NSObject
{
    
}

-(void)callCamera:(UIViewController *)target;

-(void)callPhotoAlbum:(UIViewController *)target;

@end
