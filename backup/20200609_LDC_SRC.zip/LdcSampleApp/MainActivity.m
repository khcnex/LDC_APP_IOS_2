//
//  ViewController.m
//  LdcSampleApp
//
//  Created by Woo HeeMyeong on 2018. 9. 4..
//  Copyright © 2018년 nexgrid. All rights reserved.
//

#import "MainActivity.h"

@interface MainActivity ()

@end

@implementation MainActivity

- (void)viewDidLoad
{
    
    NSLog(@"%@", @"hello");
    
    [super viewDidLoad];
    
//    [self.navigationController pushViewController:[LdcWebView new] animated:YES];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
